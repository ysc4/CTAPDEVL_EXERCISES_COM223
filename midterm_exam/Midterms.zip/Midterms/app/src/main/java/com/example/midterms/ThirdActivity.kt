package com.example.midterms

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri

class ThirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_third)

        val firstInput = intent.getStringExtra("input2")

        val displayInput2 = findViewById<TextView>(R.id.displayInput2)
        displayInput2.text = "$firstInput"

        val btnGithub = findViewById<Button>(R.id.buttonToGithub)
        val githubLink = "https://github.com/ysc4"

        btnGithub.setOnClickListener {
            val urlIntent = Intent(Intent.ACTION_VIEW, githubLink.toString().toUri())
            startActivity(urlIntent)
            finish()
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("Activity 3 Start", "Activity 3 has started")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Activity 3 Resume", "Activity 3 has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Activity 3 Pause", "Activity 3 has paused")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Activity 3 Stop", "Activity 3 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("Activity 3 Destroy", "Activity 3 has been destroyed")
    }
}