package com.example.midterms

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val inputOne = findViewById<EditText>(R.id.input1)

        val btnToSecond = findViewById<Button>(R.id.buttonToSecond)

        btnToSecond.setOnClickListener {
            val firstInput = inputOne.text.toString()

            val firstIntent = Intent(this, SecondActivity::class.java)
            firstIntent.putExtra("input1", firstInput)
            startActivity(firstIntent)
            finish()
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("Activity 1 Start", "Activity 1 has started")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Activity 1 Resume", "Activity 1 has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Activity 1 Pause", "Activity 1 has paused")
    }


    override fun onStop() {
        super.onStop()
        Log.d("Activity 1 Stop", "Activity 1 has stopped")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Activity 1 Destroy", "Activity 1 has been destroyed")
    }
}