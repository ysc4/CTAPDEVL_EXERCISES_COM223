package com.example.exercise2

data class Post(
    val id: PostID,
    val username: String,
    val imageResourceId: Int,
    val caption: String,
    val viewCount: Int,
    val commentCount: Int,
    val daysAgo: Int
)