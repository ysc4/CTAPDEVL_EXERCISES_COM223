package com.example.exercise2

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResult

class UploadFragment : Fragment(R.layout.fragment_upload) {

    private lateinit var profileView: ImageView
    private lateinit var editProfileButton: Button
    private lateinit var postImageButton: Button
    private var selectedImageUri: Uri? = null
    private var isPostImage: Boolean = false

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            selectedImageUri = it
            profileView.setImageURI(it)

            val bundle = Bundle().apply {
                if (isPostImage) {
                    putParcelable("post_image", it)
                } else {
                    putParcelable("profile_image", it)
                }
            }

            setFragmentResult("edit_profile_result", bundle)
            parentFragmentManager.popBackStack()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_upload, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        profileView = view.findViewById(R.id.editProfileImageView)
        editProfileButton = view.findViewById(R.id.uploadImageButton)
        postImageButton = view.findViewById(R.id.postImageButton)

        editProfileButton.setOnClickListener {
            isPostImage = false
            imagePickerLauncher.launch("image/*")
        }

        postImageButton.setOnClickListener {
            isPostImage = true
            imagePickerLauncher.launch("image/*")
        }
    }
}