// HomeFragment.kt - Update the fragment to use RecyclerView
package com.example.exercise2

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView

class HomeFragment : Fragment(R.layout.fragment_home) {

    private var username: String? = null
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: Adapter
    private val repository = Repository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Get the username from arguments passed to the fragment
        arguments?.let {
            username = it.getString("USERNAME")
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.instagramRecyclerView)

        // Create and set adapter with posts from repository
        adapter = Adapter(repository.getPosts())
        recyclerView.adapter = adapter

        // We don't need to set LayoutManager here as it's already set in XML
        // with app:layoutManager="androidx.recyclerview.widget.LinearLayoutManager"
    }

    companion object {
        @JvmStatic
        fun newInstance(username: String) =
            HomeFragment().apply {
                arguments = Bundle().apply {
                    putString("USERNAME", username)
                }
            }
    }
}