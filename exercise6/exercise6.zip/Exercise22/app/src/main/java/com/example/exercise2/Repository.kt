// Repository.kt - Create a repository to provide post data
package com.example.exercise2

class Repository {
    fun getPosts(): List<Post> {
        return listOf(
            Post(
                id = PostID.POST1,
                username = "travel_explorer",
                imageResourceId = R.drawable.post_image_1,
                caption = "Sunset views from the mountaintop. Worth every step of the climb! #adventure #sunset #mountains",
                viewCount = 24568,
                commentCount = 432,
                daysAgo = 2
            ),
            Post(
                id = PostID.POST2,
                username = "food_lover",
                imageResourceId = R.drawable.post_image_2,
                caption = "Homemade pasta night! Fresh ingredients make all the difference. #foodie #homecooking #pasta",
                viewCount = 18735,
                commentCount = 286,
                daysAgo = 3
            ),
            Post(
                id = PostID.POST3,
                username = "fitness_guru",
                imageResourceId = R.drawable.post_image_1,
                caption = "Morning workout routine completed! Starting the day with energy and focus. #fitness #motivation #wellness",
                viewCount = 15421,
                commentCount = 193,
                daysAgo = 1
            ),
            Post(
                id = PostID.POST4,
                username = "pet_paradise",
                imageResourceId = R.drawable.post_image_2,
                caption = "Meet Luna, our newest rescue! She's already feeling right at home. #adoptdontshop #catsofinstagram #rescue",
                viewCount = 31092,
                commentCount = 527,
                daysAgo = 5
            ),
            Post(
                id = PostID.POST5,
                username = "art_collective",
                imageResourceId = R.drawable.post_image_2,
                caption = "New exhibition opening this weekend! Come experience art in a whole new dimension. #contemporaryart #exhibition #creativity",
                viewCount = 12876,
                commentCount = 245,
                daysAgo = 2
            ),
            Post(
                id = PostID.POST6,
                username = "tech_insider",
                imageResourceId = R.drawable.post_image_1,
                caption = "Hands-on with the latest gadgets at the tech expo. The future is now! #technology #innovation #techexpo",
                viewCount = 20487,
                commentCount = 318,
                daysAgo = 4
            ),
            Post(
                id = PostID.POST7,
                username = "bookworm_cafe",
                imageResourceId = R.drawable.post_image_2,
                caption = "Current reading corner situation. What's on your reading list this month? #books #reading #cozyvibes",
                viewCount = 14356,
                commentCount = 276,
                daysAgo = 3
            ),
            Post(
                id = PostID.POST8,
                username = "urban_gardener",
                imageResourceId = R.drawable.post_image_1,
                caption = "From seed to harvest - my balcony garden is thriving! Amazing what you can grow in small spaces. #urbangardening #growyourown #sustainability",
                viewCount = 17923,
                commentCount = 304,
                daysAgo = 6
            ),
            Post(
                id = PostID.POST9,
                username = "music_vibes",
                imageResourceId = R.drawable.post_image_2,
                caption = "Backstage at tonight's concert. The energy is unreal! #livemusic #concert #backstagepass",
                viewCount = 28741,
                commentCount = 457,
                daysAgo = 1
            ),
            Post(
                id = PostID.POST10,
                username = "fashion_forward",
                imageResourceId = R.drawable.post_image_1,
                caption = "Spring collection preview - all about vibrant colors and sustainable materials this season. #fashion #springcollection #sustainablestyle",
                viewCount = 22639,
                commentCount = 389,
                daysAgo = 2
            )
        )
    }
}