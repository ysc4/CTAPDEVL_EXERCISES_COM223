// Adapter.kt - Create the RecyclerView adapter
package com.example.exercise2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class Adapter(private val posts: List<Post>) : RecyclerView.Adapter<Adapter.PostViewHolder>() {

    class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val profileImage: ImageView = itemView.findViewById(R.id.profileImageView)
        val username: TextView = itemView.findViewById(R.id.usernameTextView)
        val optionsButton: ImageView = itemView.findViewById(R.id.optionsImageView)
        val postImage: ImageButton = itemView.findViewById(R.id.postImageButton)
        val likeButton: ImageView = itemView.findViewById(R.id.likeImageView)
        val commentButton: ImageView = itemView.findViewById(R.id.commentImageView)
        val shareButton: ImageView = itemView.findViewById(R.id.shareImageView)
        val saveButton: ImageView = itemView.findViewById(R.id.saveImageView)
        val viewCount: TextView = itemView.findViewById(R.id.viewCountTextView)
        val captionText: TextView = itemView.findViewById(R.id.captionTextView)
        val commentsText: TextView = itemView.findViewById(R.id.commentsTextView)
        val daysAgoText: TextView = itemView.findViewById(R.id.daysAgoTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.post_item, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]

        // Set profile image (using placeholder)
        holder.profileImage.setImageResource(R.drawable.profile)

        // Set username
        holder.username.text = post.username

        // Set post image
        holder.postImage.setImageResource(post.imageResourceId)

        // Set view count
        holder.viewCount.text = "${post.viewCount} views"

        // Set caption
        holder.captionText.text = "${post.username} ${post.caption}"

        // Set comments count
        holder.commentsText.text = "View all ${post.commentCount} comments"

        // Set days ago
        holder.daysAgoText.text = "${post.daysAgo} days ago"
    }

    override fun getItemCount(): Int = posts.size
}