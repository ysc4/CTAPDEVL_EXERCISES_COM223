package com.example.exercise2

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide

class ProfileFragment : Fragment(R.layout.fragment_profile) {

    private lateinit var profileView: ImageView
    private lateinit var usernameProfileView: TextView
    private lateinit var editProfileButton: Button

    private var username: String? = null

    private fun addPostImage(uri: Uri) {
        val postSlot = getNextAvailablePostSlot()
        postSlot?.let {
            Glide.with(requireContext())
                .load(uri)
                .centerCrop()
                .into(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            username = it.getString("USERNAME")
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        profileView = view.findViewById(R.id.profileView)
        usernameProfileView = view.findViewById(R.id.usernameProfileView)
        editProfileButton = view.findViewById(R.id.editProfileButton)

        // Set default profile image
        profileView.setImageResource(R.drawable._60_f_115995657_rkhfauiwm4l024v7owdclbckxqbpihiz)

        usernameProfileView.text = username ?: ""

        editProfileButton.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, UploadFragment())
                .addToBackStack(null)
                .commit()
        }

        parentFragmentManager.setFragmentResultListener("edit_profile_result", this) { _, bundle ->
            bundle.getParcelable<Uri>("profile_image")?.let {
                loadProfileImage(it)
            }

            bundle.getParcelable<Uri>("post_image")?.let {
                addPostImage(it)
            }
        }

    }

    private fun loadProfileImage(imageUri: Uri) {
        Glide.with(requireContext())
            .load(imageUri)
            .circleCrop()
            .into(profileView)
    }

    private fun getNextAvailablePostSlot(): ImageView? {
        val postViews = listOf(
            view?.findViewById<ImageView>(R.id.post1),
            view?.findViewById<ImageView>(R.id.post2),
            view?.findViewById<ImageView>(R.id.post3),
            view?.findViewById<ImageView>(R.id.post4),
            view?.findViewById<ImageView>(R.id.post5),
            view?.findViewById<ImageView>(R.id.post6),
            view?.findViewById<ImageView>(R.id.post7),
            view?.findViewById<ImageView>(R.id.post8),
            view?.findViewById<ImageView>(R.id.post9)
        )

        for (imageView in postViews) {
            if (imageView?.drawable == null) {
                return imageView
            }
        }

        return null // All slots are full
    }

    companion object {
        @JvmStatic
        fun newInstance(username: String) =
            ProfileFragment().apply {
                arguments = Bundle().apply {
                    putString("USERNAME", username)
                }
            }
    }
}